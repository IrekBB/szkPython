# Plik o tej nazwie wgrany do folderu MojeTypy informuje środowisko Pythona, że cały katalog jest PAKIETEM
# Zmienna __all__ zawiera listę modułów zawartych w pakiecie:

__all__ = ['Osoba', 'Lista', 'Kartoteka', 'Lista2Kier', 'ZbiorLitery',
           'StosOgraniczony', 'FIFO', 'BST', 'USS', 'TabInt', 'GrafTabl']


