from MojeTypy import StosOgraniczony as s
x=s.StosOgraniczony(2)
x.wypisz("Zawartość stosu")
x.push(2)
x.push('A')
x.push("małe co nieco")
x.wypisz("Zawartość stosu")

