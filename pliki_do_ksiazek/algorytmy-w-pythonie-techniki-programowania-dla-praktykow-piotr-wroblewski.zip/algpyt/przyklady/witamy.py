import os
print('Zalogowany użytkownik: ', os.getlogin())
print("Na naukę Pythona nigdy nie jest za późno!")
rok_poprzedni=2021
print(f"Ta książka zostanie wydana w {rok_poprzedni +1} roku")

s = "Alicja w Krainie Czarów"
