from openai import OpenAI
API_KEY = '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' # Patrz uwagi w książce "Bezpieczeństwo klucza API"

client = OpenAI(api_key=API_KEY)
sesja = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=
    [
        {"role": "system",
         "content": "Jesteś anglistą i potrafisz korygowac błędy stylisytyczne i ortogarficzne"},
        {"role": "user",
         "content": "Popraw tekst: 'I wuld like to helpp you but speak bad Enlish sorry. Repeat please?' "}
    ]
)

resp = sesja.choices[0].message.content
print("Odpowiedź serwisu:\n", resp)

print("Liczba zużytych tokenów", sesja.usage.total_tokens)
print("w tym 'Prompt:'", sesja.usage.prompt_tokens)
print("w tym 'Completion:'", sesja.usage.completion_tokens)