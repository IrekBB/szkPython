from openai import OpenAI
API_KEY = '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' # Patrz uwagi w książce "Bezpieczeństwo klucza API"
client = OpenAI(api_key=API_KEY)

previous_messages = [
    {"role": "system",
     "content": "Jesteś anglistą i potrafisz korygować błędy stylistyczne i ortograficzne"},
    {"role": "user",
     "content": "Popraw tekst: 'I wuld like to helpp you but speak bad Enlish sorry. Repeat please?'"}
]

sesja = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=previous_messages
)
resp1 = sesja.choices[0].message.content
print("Odpowiedź serwisu (1):\n", resp1)
print(" *** Tu analizujemy odpowiedź serwisu ***")

print("Ilość zużytych tokenów (sesja 1.):", sesja.usage.total_tokens)

# Druga sesja nawiązująca  do poprzedniej interakcji:
new_message = {"role": "user",
               "content":"Popraw poprzednie zdanie w języku angielskim, aby zabrzmiało nieco opryskliwie i było bardziej zwięzłe"}

sesja = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=previous_messages + [new_message]
)

resp2 = sesja.choices[0].message.content
print("Odpowiedź serwisu (2):\n", resp2)

print("Ilość zużytych tokenów (sesja 2.):", sesja.usage.total_tokens)
