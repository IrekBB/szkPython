from openai import OpenAI
from WWW import scrape_webpage

API_KEY = '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' # Patrz uwagi w książce "Bezpieczeństwo klucza API"

url = 'https://lubimyczytac.pl/ksiazka/4637/wedlug-lotra#'
#url = 'https://lubimyczytac.pl/ksiazka/5061397/zanim-wystygnie-kawa-tom-2-opowiesci-z-kawiarni#'

rec = scrape_webpage(url, "expandTextNoJS p-expanded js-expanded mb-0")

intro = [
    {"role": "system",
     "content": "Jesteś czytelnikiem recenzji internetowych i interesuje cię opinia czytelników o książkach"},
    {"role": "user",
     "content": "W następnej wiadomości podam ci listę recenzji pewnej książki. \
     Oceń, czy recenzje są 'pozytywne', 'neutralne', 'negatywne' czy 'inne'. \
     Wyświetl tylko podsumowanie liczby recenzji w danej kategorii"}
]
recenzje = {"role": "user",
            "content": rec}

client = OpenAI(api_key=API_KEY)

sesja = client.chat.completions.create(
    model = "gpt-3.5-turbo",
    messages = intro + [recenzje]     # Kumulujemy komunikaty
)

resp = sesja.choices[0].message.content
print("Odpowiedź serwisu:\n", resp)
print("Ilość zużytych tokenów:", sesja.usage.total_tokens)