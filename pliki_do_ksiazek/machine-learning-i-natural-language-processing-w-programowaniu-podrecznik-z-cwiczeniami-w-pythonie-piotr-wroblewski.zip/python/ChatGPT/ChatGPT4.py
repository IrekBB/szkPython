import numpy as np
from openai import OpenAI
API_KEY = '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' # Patrz uwagi w książce "Bezpieczeństwo klucza API"
client = OpenAI(api_key=API_KEY)

from scipy.spatial import distance

model1 = 'text-embedding-ada-002'
model2 ='text-embedding-3-large'
model3 = 'text-embedding-3-small'

def wylicz_wektor(s, m):
    s = s.replace("\n", " ")
    resp = client.embeddings.create(
        input=s,
        model = m).data[0].embedding
    return resp
# ----------------------------------------------------------------------------------------------
doc1 = "Co Ci daje IKP i mojeIKP Internetowe Konto Pacjenta i mojeIKP to bezpłatne i bezpieczne aplikacje, \
które są bramą do cyfrowego zdrowia. Sprawdź, co załatwisz dzięki każdej z nich"

doc2 = "Masz możliwość skorzystania z dwóch bezpłatnych aplikacji Ministerstwa Zdrowia: Internetowego Konta\
 Pacjenta (IKP), na które logujesz się przez stronę pacjent.gov.pl aplikacji mobilnej mojeIKP, którą instalujesz \
 na telefonie komórkowym. Obie oferują szereg możliwości załatwiania spraw zdrowotnych online. Aplikacja na telefon\
 mojeIKP daje dostęp do większości funkcji Internetowego Konta Pacjenta, zachęca również do działań profilaktycznych.\
 Sprawdź, czy Twoja przychodnia zapewnia Ci pełen dostęp do elektronicznej dokumentacji medycznej i zamawiania e-recept."

doc3 = "Kot i psy mają ze sobą często na pieńku"
doc4 = "Wybierzemy się do zoo?"

# Wygenerowanie wektorów
resp1 = wylicz_wektor(doc1, model2)
resp2 = wylicz_wektor(doc2, model2)
resp3 = wylicz_wektor(doc3, model2)
resp4 = wylicz_wektor(doc4, model2)
# Wyliczenie odległości

cosine_dist1 = distance.cosine(resp1, resp2)
cosine_dist2 = distance.cosine(resp3, resp4)
print(resp1) # Wektor...
print("Odległość cosinusowa między tekstami 1. i 2.", cosine_dist1)
print("Odległość cosinusowa między tekstami 3. i 4.", cosine_dist2)


