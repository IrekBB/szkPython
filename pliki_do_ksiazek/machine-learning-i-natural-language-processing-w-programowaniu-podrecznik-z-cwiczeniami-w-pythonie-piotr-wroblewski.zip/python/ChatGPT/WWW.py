import requests
from bs4 import BeautifulSoup

def scrape_webpage(url, tagi):
   response = requests.get(url)
   recenzje=""
   if response.status_code == 200:
       soup = BeautifulSoup(response.text, 'html.parser')

       paragraphs = soup.find_all('p', class_=[tagi])
       i=1
       for paragraph in paragraphs:
           res=f"Nr {i}.: {paragraph.text.strip()}"
           print(res)
           recenzje=recenzje+"\n"+res
           i=i+1
   else:
       print(f"Nie udało się załadować strony, kod błędu: {response.status_code}")
   return recenzje

"""
# Przykładowe użycie
url = 'https://lubimyczytac.pl/ksiazka/4637/wedlug-lotra#' # URL strony do analizy

# Wywołanie funkcji do analizy strony
recenzje = scrape_webpage(url, "expandTextNoJS p-expanded js-expanded mb-0")
print("***")
print(recenzje)
"""


