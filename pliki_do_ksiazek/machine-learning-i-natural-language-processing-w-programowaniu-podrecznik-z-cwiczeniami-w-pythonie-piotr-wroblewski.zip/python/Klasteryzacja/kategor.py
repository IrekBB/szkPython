import pandas as pd
from sklearn.preprocessing import LabelEncoder

data = pd.DataFrame({
    'priorytet': ['niski', 'średni', 'wysoki'  , 'niski', 'średni', 'wysoki'],
    'konsola':   ['Xbox' , 'PS2'   , 'Nintendo', 'Atari', 'Atari' , 'Xbox'  ]
})
print("Dane oryginalne")
print(data)

label_encoder = LabelEncoder()
data['priorytet_LabelEnc'] = label_encoder.fit_transform(data['priorytet'])

data_onehot = pd.get_dummies(data['konsola'], prefix='konsola')
data = pd.concat([data, data_onehot], axis=1)

print("Dane przekodowane")
print(data)
data.to_excel("przekodowanie.xlsx", index=False)
