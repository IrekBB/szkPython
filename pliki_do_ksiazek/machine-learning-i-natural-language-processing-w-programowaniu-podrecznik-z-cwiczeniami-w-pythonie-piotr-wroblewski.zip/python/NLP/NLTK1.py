import nltk
from nltk.tokenize import word_tokenize

# Użyj 'wordnet', jesli planujesz eksplorować funkcje ekstrakcji synonimów lub antonimów
# lub inne złożone funkcje wymagające analizy kontekstu:
#from nltk.corpus import wordnet

from nltk import pos_tag

text = """Wrocław, środa 21.02.2024 - NLTK używa się nieco trudniej niż spaCy. Warto 
jednak poznać możliwości tej biblioteki w zastosowaniach z dziedziny przetwarzania 
języka naturalnego (NLP). Po pewnym czasie okaże się, że używanie NLTK nie jest 
takie skomplikowane!"""

tokens = word_tokenize(text, language='polish')
tags = pos_tag(tokens)

print("*** Tokeny:\n", tokens)
print("*** Tagi:\n", set(tags))

from nltk.help import upenn_tagset
print("Lista tagów Penn Treebank używanych przez NLTK")
upenn_tagset()