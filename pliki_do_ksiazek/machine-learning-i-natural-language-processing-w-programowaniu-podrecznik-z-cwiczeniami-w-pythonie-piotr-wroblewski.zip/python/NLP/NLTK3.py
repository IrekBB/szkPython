import nltk
from nltk.corpus import stopwords
from stop_words import get_stop_words # Wymaga instalacji: pip3 install stop-words lub wgrania stop-words do Pycharm
from nltk.tokenize import word_tokenize

#nltk.download('punkt')
#nltk.download('stopwords')

# Przykładowy tekst
text = ("To jest przykładowy tekst, który będzie poddany tokenizacji i usunięciu \
stopwordsów. Na sam początek będzie to dość prosty dokument, pozbawiony sensu i treści,\
 ale ilustrujący zasadę użycia tej bazy")

tokens = word_tokenize(text, language='polish') # Tokenizacja tekstu

stopwords = get_stop_words('polish')     # Wersja dla stop_words
#stopwords = set(stopwords.words()) # Wersja podstawowa NLTK
#stopwords = set(stopwords.words('polish')) # Wersja NLTK, z dodatkową bazą słów

# Usunięcie stopwords
t1  = [word for word in tokens if word.lower() not in stopwords]
t2  = [word for word in tokens if word.lower() in stopwords]

# Wyświetlenie wyników
print("Tekst oryginalny:")
print(text)
print("\nTokeny po tokenizacji:")
print(tokens)
print("\nWykryte stopwords:\n")
print(t2)
print("\nTokeny po usunięciu stopwords:")
print(t1)



