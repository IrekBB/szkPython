# pip3 install PyPDF2
import pathlib
import PyPDF2 as pf
# Uruchamiaj z folderu 'python/NLP':
katBiezacy=pathlib.Path.cwd()
plikPDF=katBiezacy / pathlib.Path("Inne/Instrukcja_Uzytkownika_PZ_wersja1.4.pdf")

def PDFtoTXT_PyPDF2(pdf_path):
    f = open(pdf_path, 'rb')
    pdf_reader = pf.PdfReader(f)
    pdf_text = [0]
    N = len(pdf_reader.pages)
    print("Liczba stron dokumentu=", N)
    for p in range(N):
        stronaBiezaca = pdf_reader.pages[p]
        pdf_text.append(stronaBiezaca.extract_text())
    f.close()
    return pdf_text
# Wywołujemy funkcję:
text = PDFtoTXT_PyPDF2(plikPDF)
print("Cały dokument:", text, "\n**********\n")
print("**** Strona 7 ****\n", text[7])

