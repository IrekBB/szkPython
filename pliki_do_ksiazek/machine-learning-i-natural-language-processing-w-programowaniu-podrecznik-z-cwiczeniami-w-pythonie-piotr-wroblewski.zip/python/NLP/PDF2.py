# pip3 install pdfplumber
import pathlib
import pdfplumber
# Uruchamiaj z folderu 'python/NLP':
katBiezacy=pathlib.Path.cwd()
plikPDF=katBiezacy / pathlib.Path("Inne/Instrukcja_Uzytkownika_PZ_wersja1.4.pdf")
def PDFtoTXT_pdfplumber(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        pdf_text = [0]
        for page in pdf.pages:
            pdf_text.append(page.extract_text())
    return pdf_text
# Wywołujemy funkcję:
text = PDFtoTXT_pdfplumber(plikPDF)
print("Cały dokument:", text, "\n**********\n")
print("**** Strona 7 ****\n", text[7])