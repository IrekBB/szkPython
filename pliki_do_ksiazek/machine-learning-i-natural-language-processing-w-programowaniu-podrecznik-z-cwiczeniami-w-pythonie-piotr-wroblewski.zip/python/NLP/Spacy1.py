import spacy
#spacy.cli.download("pl_core_news_lg") # Patrz "Instalacja i konfiguracja spaCy" (dotyczy Pycharm)
nlp = spacy.load("pl_core_news_lg")

doc = nlp("Użycie danego korpusu językowego w kodzie wymaga użycia \
           instrukcji zawierającej jego nazwę.")
print( ".---------------+------------+-------+--------+-------+-----+--------+----------.")
print(f"|text           |lemma       |pos    |tag     |dep    |shape|is_alpha|is_stop   |")
print(f"|---------------+------------+-------+--------+-------+-----+--------+-----------")
for token in doc:
    print(f"|{token.text:15}|{token.lemma_:12}|{token.pos_:7}|\
{token.tag_:8}|{token.dep_:7}|{token.shape_:5}|{token.is_alpha:8}|\
{token.is_stop:10}|")
print( ".---------------+------------+-------+--------+-------+-----+--------+----------.")
