# Uruchamiaj z folderu 'python/NLP':
import spacy
import pathlib
import pdfplumber
import time
czasstart = time.time()
t1=time.localtime()    # Czas lokalny
katBiezacy=pathlib.Path.cwd()
plikPDF=katBiezacy / pathlib.Path("Inne/Bohaterowie-niepodleglej_Pilsudski.pdf")
def PDFtoTXT_pdfplumber(pdf_path):
    pdf_str = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            pdf_str=pdf_str+page.extract_text()
    return pdf_str
text = PDFtoTXT_pdfplumber(plikPDF)

#spacy.cli.download("pl_core_news_lg") # Patrz "Instalacja i konfiguracja spaCy" (dotyczy Pycharm)
nlp = spacy.load("pl_core_news_lg")
doc = nlp(text)

print ("Analiza NER - Bohaterowie-niepodleglej_Pilsudski.pdf © Copyright by Instytut Pamięci Narodowej ")
print(".----------------------------------------------.")
print("Jednostka NER         | Etykieta  |  Objaśnienie")
print(".----------------------------------------------.")
for ent in doc.ents:
    print(f"{ent.text:35} {ent.label_:12} ")
czasend = time.time()
t2=time.localtime()
print(f"Start:  Godzina {t1.tm_hour}, minuta {t1.tm_min}, sekunda {t1.tm_sec}")
print(f"Koniec: Godzina {t2.tm_hour}, minuta {t2.tm_min}, sekunda {t2.tm_sec}")
print(f"Czas wykonania:        {czasend-czasstart}")