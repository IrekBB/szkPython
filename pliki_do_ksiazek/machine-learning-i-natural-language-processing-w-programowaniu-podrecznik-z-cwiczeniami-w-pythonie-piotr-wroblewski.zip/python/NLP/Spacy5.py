import spacy
#spacy.cli.download("pl_core_news_lg") # Patrz "Instalacja i konfiguracja spaCy" (dotyczy Pycharm)
nlp = spacy.load("pl_core_news_lg")
sw=nlp.Defaults.stop_words
print("Polskie stop words:", len(sw))
print("Stop words:", sw)
nlp = spacy.load("en_core_web_sm")
sw=nlp.Defaults.stop_words
print("Angielskie:", len(sw))
print("Stop words:", sw)
#nlp.Defaults.stop_words.add('xxx')
#nlp.Defaults.stop_words.remove('xxx')


