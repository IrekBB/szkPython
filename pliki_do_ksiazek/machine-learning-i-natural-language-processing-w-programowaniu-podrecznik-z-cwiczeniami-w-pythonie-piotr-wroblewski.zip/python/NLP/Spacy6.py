import spacy
nlp = spacy.load("pl_core_news_lg")
doc1 = nlp("Co Ci daje IKP i mojeIKP Internetowe Konto Pacjenta i mojeIKP to bezpłatne i bezpieczne aplikacje, które \
są bramą do cyfrowego zdrowia. Sprawdź, co załatwisz dzięki każdej z nich")
doc2 = nlp("Masz możliwość skorzystania z dwóch bezpłatnych aplikacji Ministerstwa Zdrowia: Internetowego Konta \
Pacjenta (IKP), na które logujesz się przez stronę pacjent.gov.pl aplikacji mobilnej mojeIKP, którą instalujesz na \
telefonie komórkowym. Obie oferują szereg możliwości załatwiania spraw zdrowotnych online. Aplikacja na telefon mojeIKP\
 daje dostęp do większości funkcji Internetowego Konta Pacjenta, zachęca również do działań profilaktycznych. Sprawdź,\
  czy Twoja przychodnia zapewnia Ci pełen dostęp do elektronicznej dokumentacji medycznej i zamawiania e-recept.")

doc3 = nlp("Kot i psy mają ze sobą często na pieńku")
doc4 = nlp("Wybierzemy się do zoo?")

similarity_score1 = doc1.similarity(doc2)
similarity_score2 = doc3.similarity(doc4)
print("Podobieństwo między tekstami:", similarity_score1)
print("Podobieństwo między tekstami:", similarity_score2)

