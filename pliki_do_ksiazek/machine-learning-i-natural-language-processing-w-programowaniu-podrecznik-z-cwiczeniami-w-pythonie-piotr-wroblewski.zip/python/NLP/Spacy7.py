import spacy
#spacy.cli.download("pl_core_news_lg") # Patrz "Instalacja i konfiguracja spaCy" (dotyczy Pycharm)
nlp = spacy.load("pl_core_news_lg")
doc = nlp("kot pies mrówka słoma skała")
print(" doc=", doc)
print("Rozmiar wektora w spaCy", doc.vector.size)
print("Wektor dla całego zdania:\n", doc.vector)
print(f"Wektor dla słowa '{doc[1].text}' w zdaniu:\n", doc[1].vector)

print("Podobieństwa między słowami:")

for token1 in doc:
    for token2 in doc:
        print(token1.text, token2.text, token1.similarity(token2))




