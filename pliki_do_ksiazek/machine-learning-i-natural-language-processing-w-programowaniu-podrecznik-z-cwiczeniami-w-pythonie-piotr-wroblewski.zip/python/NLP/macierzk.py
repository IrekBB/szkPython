dane = [
    {"Nr": 1,  "Wykryto": True,  "Przewidywano": True},
    {"Nr": 2,  "Wykryto": False, "Przewidywano": True},
    {"Nr": 3,  "Wykryto": True,  "Przewidywano": False},
    {"Nr": 4,  "Wykryto": False, "Przewidywano": False},
    {"Nr": 5,  "Wykryto": True,  "Przewidywano": True},
    {"Nr": 6,  "Wykryto": True,  "Przewidywano": False},
    {"Nr": 7,  "Wykryto": False, "Przewidywano": True},
    {"Nr": 8,  "Wykryto": True,  "Przewidywano": True},
    {"Nr": 9,  "Wykryto": False, "Przewidywano": False},
    {"Nr": 10, "Wykryto": True,  "Przewidywano": True},
    {"Nr": 11, "Wykryto": True,  "Przewidywano": False},
    {"Nr": 12, "Wykryto": False, "Przewidywano": True},
    {"Nr": 13, "Wykryto": True,  "Przewidywano": False},
    {"Nr": 14, "Wykryto": True,  "Przewidywano": True},
    {"Nr": 15, "Wykryto": False, "Przewidywano": False},
    {"Nr": 16, "Wykryto": True,  "Przewidywano": True},
    {"Nr": 17, "Wykryto": False, "Przewidywano": False},
    {"Nr": 18, "Wykryto": True,  "Przewidywano": False},
    {"Nr": 19, "Wykryto": False, "Przewidywano": True},
    {"Nr": 20, "Wykryto": False, "Przewidywano": False}
]

TP = sum(1 for d in dane if     d["Wykryto"] and     d["Przewidywano"])
FN = sum(1 for d in dane if     d["Wykryto"] and not d["Przewidywano"])
FP = sum(1 for d in dane if not d["Wykryto"] and     d["Przewidywano"])
TN = sum(1 for d in dane if not d["Wykryto"] and not d["Przewidywano"])

accuracy = (TP + TN) / len(dane)
precision = TP / (TP + FP) if (TP + FP) > 0 else 0
recall = TP / (TP + FN) if (TP + FN) > 0 else 0
f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

print("Macierz konfuzji:")
print("TP:", TP)
print("FN:", FN)
print("FP:", FP)
print("TN:", TN)
print("Dokładność:", accuracy)
print("Precyzja:", precision)
print("Czułość:", recall)
print("F1:", f1_score)