import numpy as np
t0 = np.linspace(0, 10, 5)
print("t0=", t0)
t1 = np.arange(1,11)
t2 = np.arange(1,11, 3)
t3 = np.zeros(9)
t4 = np.ones(9, dtype='i' )
t5= np.random.random(4)
t6= np.random.randint(5,10, 9)
t7= np.random.randint(3, size=(3, 5))

print("t1=", t1)
t1=t1.reshape( (2,5) )
print("t1 po reshape(2,5)=", t1)
print("t2=", t2)
print("t3=", t3)
print("t4=", t4)
print("t5=", t5)
print("t6=", t6)
print("t7=", t7)

print("Demonstracja 'resize':")

t8 = np.arange(1,11)
print("t8=", t8)
t8.resize(4,5)
print("t8 po resize (4,5) =", t8)

