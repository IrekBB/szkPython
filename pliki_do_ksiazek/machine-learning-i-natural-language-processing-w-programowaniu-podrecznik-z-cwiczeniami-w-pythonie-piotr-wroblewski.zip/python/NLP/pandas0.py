import pandas as pd # Alias nazwy pandas
t1 = [4, 2, 8]
print("Lista t1=", t1)
seria1 = pd.Series(t1)
print("Obiekt Pandas Series 'seria1' utworzony z 't1':\n", seria1)
print("Wyłuskujemy wartość 'seria[1]':", seria1[1]) # Wypisze: 2

print("Wyłuskujemy zakres seria1[1, 2]=", seria1[[1, 2]].values ) # Wypisze: [2 8]

wycinek=[True, False, True]
print("Lista pomocnicza 'wycinek'", wycinek)

print("seria1[wycinek]=", seria1[wycinek].values) # Wypisze: [4 8] (wartości na pozycjach True)

t2 = [5, 'a', "Hello"]
print("Lista 't2'=", t2)
indeksik=['a','b','c']
print("Lista 'indeksik'=", indeksik)
seria2 = pd.Series(t2, index=indeksik)
print("Obiekt Pandas Series 'seria2' utworzony z listy 't2' oraz indeksowany przez etykiety zawarte w liście 'indeksik'")
print(seria2)
print("Wycinek 'seria2['a':'b']' -->",seria2['a':'b'].values) # Wycinek
limity = {"SKU1":100.20,"SKU2":120,"SKU3":150.5,"SKU4":115,"SKU5":125}
print("Słownik Pythona o nazwie 'limity':\n", limity)

seria3 = pd.Series(limity)

print("Obiekt Pandas Series 'seria3' utworzony ze słownika 'limity'\n ", (seria3) )
print("Typ danych obiektu 'seria3' --> ", seria3.dtype)
wszedzietosamo = pd.Series(5, index=[x for x in range(6)])
print("Seria pięciu liczb 5 --> ", wszedzietosamo)