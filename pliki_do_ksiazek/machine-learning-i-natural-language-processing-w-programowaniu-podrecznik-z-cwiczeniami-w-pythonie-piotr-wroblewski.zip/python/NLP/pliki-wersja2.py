import pathlib

katDomowy=pathlib.Path.home()
katBiezacy=pathlib.Path.cwd()

pewienplik=katBiezacy / pathlib.Path("witamy.py")
# pewienplik=katalogBiezacy / "witamy.py" # Alternatywna składnia

print(f"Katalog domowy:{katDomowy} \nBieżący katalog:{katBiezacy}")
print(f"Nasz pierwszy program w Pythonie: {pewienplik}")

print(f"Dekompozycja składowych - nazwa : {pewienplik.name}")
print(f"Dekompozycja składowych - trzon : {pewienplik.stem}")
print(f"Dekompozycja składowych - sufiks: {pewienplik.suffix}")
print(f"Dekompozycja składowych - parent: {pewienplik.parent}")
print(f"Dekompozycja składowych - anchor: {pewienplik.anchor}")

katBiezacy=pathlib.Path.cwd()
katDel=katBiezacy / pathlib.Path("testdir2")
try:
    print(f"Chcemy usunąć {katDel}")
    katDel.rmdir()
except OSError:
    print("Coś poszło nie tak. Sprawdź, czy katalog istnieje lub czy nie zawiera plików")

if katDel.exists():
    print(f"Katalog {katDel} istnieje")
else:
    print(f"Katalog {katDel} nie istnieje")

if pewienplik.exists():
    print(f"Plik {pewienplik} istnieje")
else:
    print(f"Katalog {pewienplik} nie istnieje")

katNowy=pathlib.Path("testdir3")
try:
    print(f"W katalogu bieżącym tworzymy folder {katNowy}")
    katNowy.mkdir() # Ta operacja powiedzie się tylko raz...
except OSError:
    print("Coś poszło nie tak. Sprawdź, czy katalog już istnieje")