import pathlib
katalogBiezacy=pathlib.Path.cwd()  # Obiekt wskazujący na katalog bieżący
nazwapliku="inputs.txt"
plik=katalogBiezacy / nazwapliku

print("Odczytujemy plik tekstowy, używając metody 'open' z klasy 'Path'")
print("- Czytamy cały plik za jednym zamachem:")

with plik.open(mode="r", encoding="utf=8") as f:
    tekst=f.read()
print(tekst)

print("- Czytamy pojedyncze linie:")

with plik.open() as f:
    for wiersz in f.readlines():
        print(f"  Odczytany wiersz: {wiersz}", end ="")
print()