import re
telefony = "Lista telefonów: Anna: +35 250-259-211, John: +1 250-259-211, Tomek: +48 670-234-555, Antonio: +34 555-666-777"
print(telefony)

wzorzec=r"(\+(\d{2}) (\d{3})-(\d{3})-(\d{3}))"
wyrReg = re.compile(wzorzec)
wyniki=wyrReg.search((telefony))

print("Odnalazłem:", wyniki.group())

wynikiLista=wyrReg.findall((telefony))

for x in wynikiLista:
    print("Pełny numer telefonu:", x[0], " kod kierunkowy kraju=", x[1])

