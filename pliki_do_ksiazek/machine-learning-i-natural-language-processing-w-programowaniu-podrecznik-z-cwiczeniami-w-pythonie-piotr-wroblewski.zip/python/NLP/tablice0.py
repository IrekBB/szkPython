T1=[3, 4, 5]
T2=[6, 7, 8]
T3=[T1, T2]

print("T3 =", T3)
T1.append(100)
print("T3 =", T3)

print("T3[1][2]=", T3[1][2])
#print("T3[1][3] =", T3[1][3]) # Zgłosi błąd "IndexError: list index out of range"
print("Koniec")