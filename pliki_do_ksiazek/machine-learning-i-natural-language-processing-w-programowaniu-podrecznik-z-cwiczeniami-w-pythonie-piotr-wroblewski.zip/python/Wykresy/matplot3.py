import matplotlib.pyplot as plt

kategorie = ['A', 'B', 'C', 'D', 'E']
seria_1 = [13, 40, 56, 80, 34]
seria_2 = [20, 32, 60, 68, 32]
seria_3 = [12, 28, 40, 55, 20]

szer = 0.25

plt.bar([x - szer for x in range(len(kategorie))], seria_1, width=szer, label='Seria 1.', hatch='\\', color='grey')

plt.bar(range(len(kategorie)), seria_2, width=szer, label='Seria 2.', hatch='|', color='green')

plt.bar([x + szer for x in range(len(kategorie))], seria_3, width=szer, label='Seria 3.', hatch='//', color='pink')

plt.title('Wykres słupkowy dla trzech serii danych i pięciu kategorii')
plt.xlabel('Kategorie')
plt.ylabel('Wartości')
plt.xticks(range(len(kategorie)), kategorie)
plt.legend()

plt.tight_layout()
plt.show()
