import numpy as np
import matplotlib.pyplot as plt
t = np.array([-10, -5, 0, 10, 12, 15, 17, 60, 65, 70, 80, 80, 80, 80, 85, 86, 90])
plt.violinplot(t, vert=True)
plt.ylabel('Wartości')
plt.title('Wykres skrzypcowy')
plt.show()