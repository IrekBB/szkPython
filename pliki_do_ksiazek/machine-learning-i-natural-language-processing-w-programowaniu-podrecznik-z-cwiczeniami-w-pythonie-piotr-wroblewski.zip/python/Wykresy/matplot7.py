import matplotlib.pyplot as plt
import numpy as np
t = np.array([-35, -30, 10, 10, 35, 40, 40, 50, 70, 70, 80, 80, 80, 80, 100, 100, 100, 190, 200])
plt.boxplot(t)
plt.title('Wykres pudełkowy')
plt.ylabel('Wartości')
plt.axhline(0, color='c', linestyle='--')
plt.show()
