import numpy as np
import matplotlib.pyplot as plt

data = np.array(
    [[1,  2,  2,   3, 5,  5,   5,  5,  6,  7],
     [6,  6,  7,   7, 8,  9,  15, 15, 15, 20],
     [11, 11, 13, 14, 15, 15, 15, 15, 16, 25],
     [2,  3,   3,  4, 5,   6, 11, 12, 13, 15],
     [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    ])

plt.imshow(data, cmap='hot', interpolation='nearest')

for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        plt.text(j, i, str(data[i, j]), ha='center', va='center', color='white')

plt.colorbar()
plt.xlabel('Punkty danych')
plt.title('Mapa cieplna (ang. heatmap)')
plt.show()
