lista={12, 13, 50, 60, 70, 100}
koniec=5
i=0
while i < 10:
    print("i=", i) # Poniżej ustawimy breakpoint
    i=i+1       
    if i==koniec:
        break
print("Do widzenia")
