import os
print('Zalogowany użytkownik: ', os.getlogin())
print("Programowanie ML i NLP w Pythonie nie jest trudne")
rok_poprzedni=2023
print(f"Ta książka zostanie wydana w {rok_poprzedni +1} roku")
s = "Alicja w Krainie Czarów"
print(s)