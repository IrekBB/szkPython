from zespolone import * # Lub: "from zespolone import Complex"
x = Complex(4,2)
y = Complex(2,-5)
print(f" x = {x}, y = {y}, x+y={x+y}")

