class Complex:
       def __init__(self, pRe=0, pIm=0, pKomentarz=""):
              self.__re = pRe
              self.__im = pIm
              self.komentarz=pKomentarz
              print("Narodził się nowy obiekt... Nie zapomnij o deklaracji 800+")

       def __str__(self):
              if self.im >= 0:
                     return str(self.__re) + "+" + str(self.__im) + "*i"
              else:
                     return str(self.__re) + str(self.__im) + "*i"
       def wypisz(self):
              print(self.komentarz)

       def dodaj(self, x2):
              self.__im = self.__im + x2.__im
              self.__re = self.__re + x2.__re

       # Arytmetyka liczb zespolonych: jeśli x1=a+b·i oraz x2=c+d·i to x1+x2 = (a+c) + (b + d)·i
       def __add__(self, x2):
              return Complex(self.__re + x2.__re, self.__im + x2.__im)
       @property
       def re(self):
              return self.__re
       @re.setter
       def re(self, korekta):
              self.__re= korekta
       @property
       def im(self):
              return self.__im