# Zapisz plik na dysku pod nazwą bash.sh i w folderze, w którym się on znajduje użyj komendy
# 'chmod u+x bash.sh' aby umożliwić jego wykonywanie przez użytkownika
echo "** Cześć, tutaj Twój skrypt Linux**"
echo "Wykonam komendę who (sprawdzanie, kto jest zalogowany na komputerze)"
who
echo "Wykonam komendę date (wyświetlenie daty i godziny)"
date
echo "** Do widzenia, Twój skrypt Linux zakończył działanie! **"

