print("Witajcie, testerzy!")
