# Pobieranie danych - brak obsługi wyjątków
imie =input("Podaj imię:")
wiek =int (input ("Ile masz lat?"))  # Oczekiwana będzie liczba!

print (f"Imię: {imie}, wiek: {wiek}")

input("Naciśnij dowolny klawisz...")
print ("Do widzenia!")
