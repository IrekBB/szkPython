# Plik o tej nazwie wgrany do folderu mytoolkit informuje środowisko    Pythona, że cały katalog jest PAKIETEM
# Zmienna __all__ zawiera listę modułów zawartych w pakiecie:

__all__ = ["matematyczne", "pomocnicze"]


