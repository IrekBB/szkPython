def dodaj(a, b):
    return a+b
def odejmij(a, b):
    return a-b
