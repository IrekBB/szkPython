def drukuj(komentarz):
    print(komentarz)