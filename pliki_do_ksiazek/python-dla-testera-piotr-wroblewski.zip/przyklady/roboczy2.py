#Uwaga, brak kontroli błędów
import sys
timing1 = sys.argv[1] # Odczytujemy parametr 1.
timing2 = sys.argv[2] # Odczytujemy parametr 2.
res=int(timing1)-int(timing2)
print("roboczy2.py w akcji!")
print("  Wynik=timing1-timing2=",res)
