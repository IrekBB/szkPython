import LiczbyZespolone
x = LiczbyZespolone.Complex(5,8)                # Tworzymy nowy obiekt x = 5 + 8*i
y = LiczbyZespolone.Complex(1,2)                # Tworzymy nowy obiekt y = 1 + 2*i
print(f"Obiekt 'x' to [{x}]")
print(f"Obiekt 'y' to [{y}]")
z=x+y
print(f"Obiekt z=x+y to [{z}]") # Sprawdźmy wynik dodawania x+y

